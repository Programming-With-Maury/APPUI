from __future__ import annotations

__all__ = [
    "create_app",
]

from .server import create_app  # noqa: E402

__version__ = "0.1.0"


